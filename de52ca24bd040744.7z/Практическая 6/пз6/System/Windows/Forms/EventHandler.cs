﻿namespace System.Windows.Forms
{
    internal class EventHandler
    {
        private Action<object, EventArgs> path2_MouseEnter;

        public EventHandler(Action<object, EventArgs> path2_MouseEnter)
        {
            this.path2_MouseEnter = path2_MouseEnter;
        }
    }
}