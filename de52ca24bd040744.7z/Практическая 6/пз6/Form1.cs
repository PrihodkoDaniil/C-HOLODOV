﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace пз6
{
    public partial class Form1 : Form
    {

        private object currObject = null;
        int d;
        
        public Form1()
        {
            this.MouseMove += new MouseEventHandler(mouseEvent);
            //this.MouseClick += new MouseEventHandler(mouseClick);
            InitializeComponent();
            path = new GraphicsPath();
            path2 = new GraphicsPath();
            path3 = new GraphicsPath();
            pathColor = Color.Yellow;
            pathColor2 = Color.Green;
            countColor = Color.Black;
            n = 8;

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            
            if (radioButton2.Checked) 
            {
                rx1 += 1;
                if (rx1 >= 30)
                {
                    rx1 = 0;
                }
                pbox.Invalidate();
            }
            if (radioButton1.Checked)
            {
                n += d;
                if (n == 16)
                {
                    d=0;
                    d = -1;
                }
               
                if (n <= 8)
                {
                    d = 0;
                    d = 1;
                }
                pbox.Invalidate();
            }
        }


        private void mouseEvent(object sender, MouseEventArgs e)
        {
            if (currObject != null)
                currObject.GetType().GetProperty("Location").SetValue(currObject, new Point(Cursor.Position.X, Cursor.Position.Y));
        }


        float n;
        int x, y;
        Color pathColor;
        Color pathColor2;
        GraphicsPath path;
        GraphicsPath path2;
        GraphicsPath path3;
        Color countColor;
        int rx1;




        private void pbox_Paint(object sender, PaintEventArgs e)
        {
            
            Graphics g = e.Graphics;
            g.Clear(Color.White);
            Pen myPen = new Pen(Color.Black, 1);
            Pen Pen = new Pen(pathColor2, 0);
            Point[] myPoint =
            {
                new Point(401,165),
                new Point(401,180),
                new Point(401,182),
                new Point(415,190),
                new Point(420,192),
                new Point(423,194),
                new Point(425,198),
                new Point(435,190),
                new Point(420,172),
            };
            g.DrawClosedCurve(Pen, myPoint);


            Pen Pen2 = new Pen(pathColor, 1);
            Point[] myPoint2 =
            {
                 new Point(365,198),
                new Point(366,190),
                new Point(370,198),
                new Point(366,210)
            };
            g.DrawClosedCurve(Pen2, myPoint2);


            path2.Reset();
            path2.StartFigure();
            path2.AddClosedCurve(myPoint);
            path2.CloseFigure();
            SolidBrush mySolidBrush = new SolidBrush(pathColor2);
            g.FillPath(mySolidBrush, path2);
            g.DrawPath(myPen, path2);

            path.Reset();
            path.StartFigure();
            path.AddClosedCurve(myPoint2);
            path.CloseFigure();
            SolidBrush mySolidBrush2 = new SolidBrush(pathColor);
            g.FillPath(mySolidBrush2, path);
            g.DrawPath(myPen, path);

            SolidBrush br = new SolidBrush(Color.Black);
            Pen pn = new Pen(Color.Black, 1);
            g.DrawLine(pn, 300, 200, 500, 200);
            g.DrawLine(pn, 400, 300, 400, 100);
            g.DrawEllipse(pn, 365, 145, 70, 70);
            g.DrawEllipse(pn, 365, 165, 70, 70);
            g.DrawEllipse(pn, 365, 185, 70, 70);
            g.FillEllipse(br, 398, 182, 5, 5);
            g.FillEllipse(br, 398, 162, 5, 5);
            g.FillEllipse(br, 398, 142, 5, 5);
            g.FillEllipse(br, 362, 198, 5, 5);
            g.FillEllipse(br, 425, 198, 5, 5);
            g.FillEllipse(br, 433, 198, 5, 5);

            
            Font fnt = new System.Drawing.Font("Arial", (float)n);
            Brush brush = new SolidBrush(countColor);
            Point r2 = new Point(390, 187);
            Point r3 = new Point(390, 167);
            Point r4 = new Point(390, 147);
            Point r5 = new Point(423, 203);
            Point r6 = new Point(435, 203);
            Point r7 = new Point(355, 203);
            Point r8 = new Point(390, 235);
            Point rx = new Point(500+rx1, 198);
            Point ry = new Point(390+rx1, 100);
            g.DrawString("1", fnt, brush, r2);
            g.DrawString("2", fnt, brush, r3);
            g.DrawString("3", fnt, brush, r4);
            g.DrawString("1", fnt, brush, r5);
            g.DrawString("2", fnt, brush, r6);
            g.DrawString("2", fnt, brush, r7);
            g.DrawString("2", fnt, brush, r8);
            g.DrawString("x", fnt, brush, rx);
            g.DrawString("y", fnt, brush, ry);

            
        }
        private void pbox_MouseMove(object sender, MouseEventArgs e)
        {
            Point loc = new Point(e.X, e.Y);
            if (path.IsVisible(loc))
            { 
                pathColor = RandomColor();
                pbox.Invalidate();   
            }
            if (path2.IsVisible(loc))
            {
                pathColor2 = RandomColor();
                pbox.Invalidate();  
            }
            

        }


        //кнопка для смены цвета 
        private void button1_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.FullOpen = true;
            dlg.ShowHelp = true;
            dlg.Color = pathColor;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                pathColor = dlg.Color;
                pathColor2 = dlg.Color;
                pbox.Invalidate();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.FullOpen = true;
            dlg.ShowHelp = true;
            dlg.Color = pathColor;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                countColor = dlg.Color;
                pbox.Invalidate();
            }
        }

        private void pbox_MouseDown(object sender, MouseEventArgs e)
        {
            Point loc = new Point(e.X, e.Y);
           
        }

        private void x1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point pos = new Point(Cursor.Position.X - x, Cursor.Position.Y - y);
                x1.Location = PointToClient(pos);
            }
        }

        private void y1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point pos = new Point(Cursor.Position.X - x, Cursor.Position.Y - y);
                y1.Location = PointToClient(pos);
            }
        }

        private void x2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point pos = new Point(Cursor.Position.X - x, Cursor.Position.Y - y);
                x2.Location = PointToClient(pos);
            }
        }

        private void x22_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point pos = new Point(Cursor.Position.X - x, Cursor.Position.Y - y);
                x22.Location = PointToClient(pos);
            }
        }

        private void y2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point pos = new Point(Cursor.Position.X - x, Cursor.Position.Y - y);
                y2.Location = PointToClient(pos);
            }
        }

        private void y22_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point pos = new Point(Cursor.Position.X - x, Cursor.Position.Y - y);
                y22.Location = PointToClient(pos);
            }
        }

        private void y3_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point pos = new Point(Cursor.Position.X - x, Cursor.Position.Y - y);
                y3.Location = PointToClient(pos);
            }
        }

        

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }


        //метод для рандомного цвета
        public Color RandomColor()
        {
            int r, g, b;
            byte[] bytes1 = new byte[3];     
            Random rnd1 = new Random();      
            rnd1.NextBytes(bytes1);          
            r = Convert.ToInt16(bytes1[0]);
            g = Convert.ToInt16(bytes1[1]);
            b = Convert.ToInt16(bytes1[2]);
            return Color.FromArgb(r, g, b);
        }
    }   
}

