﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace Практическая_6
{
    public partial class Form1 : Form
    {
        private object currObject = null;
        Color Color;
        Color pathColor2;
        GraphicsPath path1;
        GraphicsPath path2;
        Color countColor;
        public Form1()
        {
            InitializeComponent();
            this.MouseMove += new MouseEventHandler(mouseEvent);
            InitializeComponent();
            path1 = new GraphicsPath();
            path2 = new GraphicsPath();
            Color = Color.Yellow;
            pathColor2 = Color.Green;
            countColor = Color.Black;
        }

        private void mouseEvent(object sender, MouseEventArgs e)
        {
            if (currObject != null)
                currObject.GetType().GetProperty("Location").SetValue(currObject, new Point(Cursor.Position.X, Cursor.Position.Y));
        }
        
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            Point loc = new Point(e.X, e.Y);
            if (path1.IsVisible(loc))
            {
                Color = RandomColor();
                pictureBox1.Invalidate();
            }
            if (path2.IsVisible(loc))
            {
                pathColor2 = RandomColor();
                pictureBox1.Invalidate();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.FullOpen = false;
            dlg.ShowHelp = true;
            dlg.Color = Color;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                Color = dlg.Color;
                pathColor2 = dlg.Color;
                pictureBox1.Invalidate();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.FullOpen = true;
            dlg.ShowHelp = true;
            dlg.Color = countColor;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                countColor = dlg.Color;
                pictureBox1.Invalidate();
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics gr =  e.Graphics;
            gr.Clear(Color.White);
            Pen pn = new Pen(Color.Black,1);
            Pen col = new Pen(Color.Black, 1);
            SolidBrush br=new SolidBrush(Color.Black);      
            pn.CustomEndCap = new AdjustableArrowCap(6, 6);
            Pen Pen = new Pen(pathColor2, 0);
            Point[] myPoint =
            {
                new Point(401,165),
                new Point(401,180),
                new Point(401,182),
                new Point(415,190),
                new Point(420,192),
                new Point(423,194),
                new Point(425,198),
                new Point(435,190),
                new Point(420,172),
            };
            gr.DrawClosedCurve(col, myPoint);
            Pen Pen2 = new Pen(Color, 0);
            Point[] myPoint1 =
            {
                new Point(365,198),
                new Point(366,190),
                new Point(370,198),
                new Point(366,210)
            };
            gr.DrawClosedCurve(col, myPoint1);

            path2.Reset();
            path2.StartFigure();
            path2.AddClosedCurve(myPoint);
            path2.CloseFigure();
            SolidBrush mySolidBrush = new SolidBrush(pathColor2);
            gr.FillPath(mySolidBrush, path2);
            gr.DrawPath(Pen, path2);

            path1.Reset();
            path1.StartFigure();
            path1.AddClosedCurve(myPoint1);
            path1.CloseFigure();
            SolidBrush mySolidBrush2 = new SolidBrush(Color);
            gr.FillPath(mySolidBrush2, path1);
            gr.DrawPath(Pen2, path1);

            gr.DrawLine(pn, 300,200,500,200);
            gr.DrawLine(pn, 400, 300, 400, 100);
            gr.DrawEllipse(pn, 365, 145, 70, 70);
            gr.DrawEllipse(pn,365,165,70,70);
            gr.DrawEllipse(pn, 365, 185, 70, 70);
            gr.FillEllipse(br, 398, 182, 5, 5);
            gr.FillEllipse(br, 398, 162, 5, 5);
            gr.FillEllipse(br, 398, 142, 5, 5);
            gr.FillEllipse(br, 362, 198, 5, 5);//
            gr.FillEllipse(br, 425, 198, 5, 5);
            gr.FillEllipse(br, 433, 198, 5, 5);

            Font fnt = new System.Drawing.Font("Arial", (float)8);
            Brush brush = new SolidBrush(countColor);
            Point r2 = new Point(390,187);
            Point r3 = new Point(390, 167);
            Point r4 = new Point(390, 147);
            Point r5 = new Point(423, 203);
            Point r6 = new Point(435, 203);
            Point r7 = new Point(355, 203);
            Point r8 = new Point(390, 235);
            Point rx = new Point(500, 198);
            Point ry = new Point(390, 100);
            gr.DrawString("1", fnt, brush, r2);
            gr.DrawString("2", fnt, brush, r3);
            gr.DrawString("3", fnt, brush, r4);
            gr.DrawString("1", fnt, brush, r5);
            gr.DrawString("2", fnt, brush, r6);
            gr.DrawString("2", fnt, brush, r7);
            gr.DrawString("2", fnt, brush, r8);
            gr.DrawString("x", fnt, brush, rx);
            gr.DrawString("y", fnt, brush, ry);
            FontFamily[] label = FontFamily.Families;
            pictureBox1.Invalidate();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        public Color RandomColor()
        {
            int r, g, b;
            byte[] bytes1 = new byte[3];     
            Random rnd1 = new Random();      
            rnd1.NextBytes(bytes1);          
            r = Convert.ToInt16(bytes1[0]);
            g = Convert.ToInt16(bytes1[1]);
            b = Convert.ToInt16(bytes1[2]);

            return Color.FromArgb(r, g, b);  
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            Point loc = new Point(e.X, e.Y);
        }
    }
}
